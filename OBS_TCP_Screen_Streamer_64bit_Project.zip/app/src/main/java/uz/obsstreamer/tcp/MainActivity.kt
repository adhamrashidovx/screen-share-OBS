package uz.obsstreamer.tcp

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var settings: StreamSettings
    private lateinit var statusText: TextView
    private lateinit var urlText: TextView
    private lateinit var audioSourceBtn: Button
    private lateinit var startStopBtn: Button
    private lateinit var logsText: TextView
    private lateinit var streamingContainer: View
    private lateinit var logsContainer: View
    private lateinit var tabStreamingBtn: TextView
    private lateinit var tabLogsBtn: TextView

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenStreamService::class.java).apply {
                action = ScreenStreamService.ACTION_START
                putExtra(ScreenStreamService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenStreamService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        requestScreenCapture()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = StreamSettings(this)
        setContentView(buildMainUi())
    }

    override fun onResume() {
        super.onResume()
        ScreenStreamService.onStateListener = {
            runOnUiThread { refreshUiState() }
        }
        refreshUiState()
    }

    override fun onPause() {
        super.onPause()
        ScreenStreamService.onStateListener = null
    }

    override fun onStop() {
        super.onStop()
        if (!settings.backgroundMirroring && ScreenStreamService.isServiceRunning && isFinishing) {
            stopStreamingService()
        }
    }

    private fun startStreamingWithPermissions() {
        val perms = mutableListOf<String>()
        if (settings.audioSource != AudioSourceType.NONE &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            perms.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (perms.isNotEmpty()) {
            permissionLauncher.launch(perms.toTypedArray())
        } else {
            requestScreenCapture()
        }
    }

    private fun requestScreenCapture() {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun stopStreamingService() {
        val stopIntent = Intent(this, ScreenStreamService::class.java).apply {
            action = ScreenStreamService.ACTION_STOP
        }
        startService(stopIntent)
    }

    private fun refreshUiState() {
        val running = ScreenStreamService.isServiceRunning
        val clients = ScreenStreamService.connectedClientsCount
        val ips = TcpStreamServer.getLocalIpAddresses(settings.usbAdbMode)
        val primaryIp = ips.firstOrNull()?.second ?: "127.0.0.1"
        val primaryUrl = "tcp://$primaryIp:${settings.tcpPort}"

        val extraIps = if (ips.size > 1) {
            "\n(" + ips.joinToString(", ") { "${it.first}: tcp://${it.second}:${settings.tcpPort}" } + ")"
        } else ""

        urlText.text = "Mirroring available at:\n$primaryUrl$extraIps"
        audioSourceBtn.text = "Audio source: ${settings.audioSource.label}"

        if (!running) {
            statusText.text = "Mirroring is PAUSED (Tap START below)"
            statusText.setTextColor(Color.parseColor("#757575"))
            startStopBtn.text = "START MIRRORING"
            startStopBtn.setBackgroundColor(Color.parseColor("#0288D1"))
        } else if (clients == 0) {
            statusText.text = "Server READY — Waiting for OBS / VLC to connect..."
            statusText.setTextColor(Color.parseColor("#EF6C00"))
            startStopBtn.text = "STOP MIRRORING"
            startStopBtn.setBackgroundColor(Color.parseColor("#D32F2F"))
        } else {
            statusText.text = "STREAMING LIVE TO OBS / VLC ($clients connected)"
            statusText.setTextColor(Color.parseColor("#2E7D32"))
            startStopBtn.text = "STOP MIRRORING"
            startStopBtn.setBackgroundColor(Color.parseColor("#D32F2F"))
        }

        logsText.text = if (ScreenStreamService.logs.isEmpty()) {
            "No logs yet. Tap START MIRRORING to initialize TCP MPEG-TS server."
        } else {
            ScreenStreamService.logs.joinToString("\n")
        }
    }

    private fun showAudioSourceDialog() {
        val items = AudioSourceType.entries.map { it.label }.toTypedArray()
        val currentIdx = AudioSourceType.entries.indexOf(settings.audioSource)
        AlertDialog.Builder(this)
            .setTitle("Select Audio Source")
            .setSingleChoiceItems(items, currentIdx) { dialog, which ->
                settings.audioSource = AudioSourceType.entries[which]
                refreshUiState()
                dialog.dismiss()
            }
            .show()
    }

    private fun buildMainUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E0E0E0"))
        }

        // Top App Bar (#039BE5 matching screenshot)
        val appBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#039BE5"))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleView = TextView(this).apply {
            text = "Screen Stream Mirroring"
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val settingsTopBtn = TextView(this).apply {
            text = "SETTINGS"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }
        appBar.addView(titleView)
        appBar.addView(settingsTopBtn)
        root.addView(appBar)

        // Tabs Bar (STREAMING | LOGS)
        val tabsBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#039BE5"))
        }
        tabStreamingBtn = TextView(this).apply {
            text = "STREAMING"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { switchTab(true) }
        }
        tabLogsBtn = TextView(this).apply {
            text = "LOGS"
            setTextColor(Color.parseColor("#B3E5FC"))
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { switchTab(false) }
        }
        tabsBar.addView(tabStreamingBtn)
        tabsBar.addView(tabLogsBtn)
        root.addView(tabsBar)

        // STREAMING TAB CONTENT
        val streamScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
        val streamContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(16), dp(12), dp(16))
        }

        // Badge: 64-Bit Pro Edition (Unlocked, Zero Ads)
        val badge = TextView(this).apply {
            text = "64-BIT FULL PRO EDITION (H.264 + AAC MPEG-TS)"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0277BD"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(18)
            }
        }
        streamContent.addView(badge)

        // Card 1: VLC | OBS Banner Card
        val vlcObsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBackground()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }
        val bannerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(130)
            )
        }
        val vlcBox = TextView(this).apply {
            text = "VLC"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#F57C00"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val obsBox = TextView(this).apply {
            text = "OBS Studio"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        bannerRow.addView(vlcBox)
        bannerRow.addView(obsBox)
        vlcObsCard.addView(bannerRow)

        val connectHint = TextView(this).apply {
            text = "Connect to the mirroring URL with VLC or OBS Media Source to start mirroring."
            textSize = 15f
            setTextColor(Color.parseColor("#616161"))
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(6))
        }
        vlcObsCard.addView(connectHint)

        statusText = TextView(this).apply {
            text = "Mirroring is PAUSED"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#757575"))
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(4), dp(16), dp(16))
        }
        vlcObsCard.addView(statusText)
        streamContent.addView(vlcObsCard)

        // Card 2: Mirroring URL + Settings Gear + Audio Source Pill
        val urlCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBackground()
            setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(16) }
        }

        val urlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        urlText = TextView(this).apply {
            text = "Mirroring available at:\ntcp://192.168.1.6:5000"
            textSize = 16f
            setTextColor(Color.parseColor("#424242"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val ips = TcpStreamServer.getLocalIpAddresses(settings.usbAdbMode)
                val primaryUrl = "tcp://${ips.firstOrNull()?.second ?: "127.0.0.1"}:${settings.tcpPort}"
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("OBS Stream URL", primaryUrl))
                Toast.makeText(this@MainActivity, "Copied: $primaryUrl", Toast.LENGTH_SHORT).show()
            }
        }
        val gearBtn = Button(this).apply {
            text = "⚙"
            textSize = 20f
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }
        urlRow.addView(urlText)
        urlRow.addView(gearBtn)
        urlCard.addView(urlRow)

        audioSourceBtn = Button(this).apply {
            text = "Audio source: Microphone + internal"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = pillBackground("#039BE5")
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
            setOnClickListener { showAudioSourceDialog() }
        }
        urlCard.addView(audioSourceBtn)
        streamContent.addView(urlCard)

        // Start / Stop Action Button
        startStopBtn = Button(this).apply {
            text = "START MIRRORING"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0288D1"))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener {
                if (ScreenStreamService.isServiceRunning) {
                    stopStreamingService()
                } else {
                    startStreamingWithPermissions()
                }
            }
        }
        streamContent.addView(startStopBtn)

        streamScroll.addView(streamContent)
        streamingContainer = streamScroll
        root.addView(streamingContainer)

        // LOGS TAB CONTENT
        val logsScroll = ScrollView(this).apply {
            visibility = View.GONE
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
        logsText = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#212121"))
        }
        logsScroll.addView(logsText)
        logsContainer = logsScroll
        root.addView(logsContainer)

        return root
    }

    private fun switchTab(showStreaming: Boolean) {
        streamingContainer.visibility = if (showStreaming) View.VISIBLE else View.GONE
        logsContainer.visibility = if (showStreaming) View.GONE else View.VISIBLE
        tabStreamingBtn.setTextColor(if (showStreaming) Color.WHITE else Color.parseColor("#B3E5FC"))
        tabLogsBtn.setTextColor(if (!showStreaming) Color.WHITE else Color.parseColor("#B3E5FC"))
    }

    private fun cardBackground() = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(4).toFloat()
        setColor(Color.WHITE)
    }

    private fun pillBackground(hexColor: String) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(24).toFloat()
        setColor(Color.parseColor(hexColor))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
