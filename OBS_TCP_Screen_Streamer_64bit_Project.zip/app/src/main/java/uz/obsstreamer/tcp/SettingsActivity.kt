package uz.obsstreamer.tcp

import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Complete Settings Screen matching all 3 settings pages from the screenshots:
 * 1. Stream format (MPEG-TS), Streaming port (5000), Stream through USB (Option A & Option B), Background mirroring
 * 2. Resolution (480p/720p/1080p), Max framerate (15–60 fps), Encoding bitrate (4096 Kbit/s + ENTER VALUE),
 *    Encoding format (H264 [Hardware 64-bit]), Force landscape display, Auto rotate
 * 3. Audio source (Microphone + internal), Audio bitrate (128 Kbit/s), [Internal] Volume (100%), [Microphone] Volume (100%)
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var settings: StreamSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = StreamSettings(this)
        setContentView(buildSettingsUi())
    }

    private fun buildSettingsUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }

        // Top Bar
        val appBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#039BE5"))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = TextView(this).apply {
            text = "←  Screen Stream Mirroring"
            setTextColor(Color.WHITE)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { finish() }
        }
        appBar.addView(backBtn)
        root.addView(appBar)

        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(28))
        }

        // --- SECTION 1: NETWORK & USB SETTINGS (Screenshot 12118.jpg) ---
        container.addView(makeItemTitle("Stream format: MPEG-TS", "Choose your favorite stream format (ISO/IEC 13818-1 for OBS & VLC)"))

        val portView = makeItemTitle("Streaming port: ${settings.tcpPort}", "Tap to change TCP listening port (default: 5000)")
        portView.setOnClickListener {
            showNumberDialog("Streaming Port (1024 - 65535)", settings.tcpPort) { newPort ->
                settings.tcpPort = newPort
                recreate()
            }
        }
        container.addView(portView)

        val usbOptionA = makeItemTitle(
            "Stream through USB (option A)",
            "If available on your device click here to go to system settings and enable USB tethering."
        )
        usbOptionA.setOnClickListener {
            try {
                val tetherIntent = Intent().apply {
                    component = ComponentName("com.android.settings", "com.android.settings.TetherSettings")
                }
                startActivity(tetherIntent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            }
        }
        container.addView(usbOptionA)

        container.addView(
            makeSwitchItem(
                "Stream through USB (option B)",
                "Enable if Option A is not available. Run `adb forward tcp:${settings.tcpPort} tcp:${settings.tcpPort}` on your PC and connect to tcp://127.0.0.1:${settings.tcpPort} in OBS.",
                settings.usbAdbMode
            ) { settings.usbAdbMode = it }
        )

        container.addView(
            makeSwitchItem(
                "Background mirroring",
                "Activate if you want mirroring to be always available, even after you quit the app",
                settings.backgroundMirroring
            ) { settings.backgroundMirroring = it }
        )

        // --- SECTION 2: VIDEO ENCODING SETTINGS (Screenshot 12119.jpg) ---
        val resItem = makeItemTitle(
            "Resolution: ${settings.resolutionHeight}p",
            "Changes the display size of video (impacts quality)"
        )
        resItem.setOnClickListener {
            val options = arrayOf("480p", "720p", "1080p")
            val values = intArrayOf(480, 720, 1080)
            AlertDialog.Builder(this)
                .setTitle("Select Resolution")
                .setItems(options) { _, which ->
                    settings.resolutionHeight = values[which]
                    recreate()
                }
                .show()
        }
        container.addView(resItem)

        container.addView(
            makeSliderItem(
                titlePrefix = "Max framerate",
                unit = "fps",
                subtitle = "Changes the smooth flow of video",
                minVal = 15,
                maxVal = 60,
                currentVal = settings.maxFps
            ) { settings.maxFps = it }
        )

        val bitrateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val bitrateSlider = makeSliderItem(
            titlePrefix = "Encoding bitrate",
            unit = "Kbit/s",
            subtitle = "Changes the quality of video",
            minVal = 512,
            maxVal = 16000,
            currentVal = settings.videoBitrateKbps
        ) { settings.videoBitrateKbps = it }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val enterValBtn = Button(this).apply {
            text = "ENTER\nVALUE"
            textSize = 12f
            setTextColor(Color.parseColor("#0288D1"))
            setOnClickListener {
                showNumberDialog("Encoding bitrate (Kbit/s)", settings.videoBitrateKbps) { v ->
                    settings.videoBitrateKbps = v
                    recreate()
                }
            }
        }
        bitrateRow.addView(bitrateSlider)
        bitrateRow.addView(enterValBtn)
        container.addView(bitrateRow)

        container.addView(
            makeItemTitle(
                "Encoding format: H264 [Hardware 64-bit]",
                "Zero-copy Surface MediaCodec hardware encoder with automatic SPS/PPS & keep-alive frames"
            )
        )

        container.addView(
            makeSwitchItem(
                "Force landscape display",
                "This option can be used when we want to force display to always be with landscape resolution.",
                settings.forceLandscape
            ) { settings.forceLandscape = it }
        )

        container.addView(
            makeSwitchItem(
                "Auto rotate",
                "Auto rotate video with device",
                settings.autoRotate
            ) { settings.autoRotate = it }
        )

        // --- SECTION 3: AUDIO SETTINGS (Screenshot 12120.jpg) ---
        val audioSourceItem = makeItemTitle(
            "Audio source: ${settings.audioSource.label}",
            "Select the audio source you want to use"
        )
        audioSourceItem.setOnClickListener {
            val items = AudioSourceType.entries.map { it.label }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Audio Source")
                .setItems(items) { _, which ->
                    settings.audioSource = AudioSourceType.entries[which]
                    recreate()
                }
                .show()
        }
        container.addView(audioSourceItem)

        container.addView(
            makeSliderItem(
                titlePrefix = "Encoding bitrate",
                unit = "Kbit/s",
                subtitle = "Changes the quality of audio",
                minVal = 64,
                maxVal = 320,
                currentVal = settings.audioBitrateKbps
            ) { settings.audioBitrateKbps = it }
        )

        container.addView(
            makeSliderItem(
                titlePrefix = "[Internal] Volume",
                unit = "%",
                subtitle = "Adjust volume for the internal audio source",
                minVal = 0,
                maxVal = 200,
                currentVal = settings.internalVolumePercent
            ) { settings.internalVolumePercent = it }
        )

        container.addView(
            makeSliderItem(
                titlePrefix = "[Microphone] Volume",
                unit = "%",
                subtitle = "Adjust volume for the microphone audio source",
                minVal = 0,
                maxVal = 200,
                currentVal = settings.micVolumePercent
            ) { settings.micVolumePercent = it }
        )

        scroll.addView(container)
        root.addView(scroll)
        return root
    }

    private fun makeItemTitle(title: String, subtitle: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(12))
            addView(TextView(this@SettingsActivity).apply {
                text = title
                textSize = 17f
                setTextColor(Color.parseColor("#111111"))
            })
            addView(TextView(this@SettingsActivity).apply {
                text = subtitle
                textSize = 14f
                setTextColor(Color.parseColor("#0288D1"))
            })
        }
    }

    private fun makeSwitchItem(
        title: String,
        subtitle: String,
        initial: Boolean,
        onChanged: (Boolean) -> Unit
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        val textCol = makeItemTitle(title, subtitle).apply {
            setPadding(0, 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sw = Switch(this).apply {
            isChecked = initial
            setOnCheckedChangeListener { _, isChecked -> onChanged(isChecked) }
        }
        row.addView(textCol)
        row.addView(sw)
        return row
    }

    private fun makeSliderItem(
        titlePrefix: String,
        unit: String,
        subtitle: String,
        minVal: Int,
        maxVal: Int,
        currentVal: Int,
        onValueChange: (Int) -> Unit
    ): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        val titleTv = TextView(this).apply {
            text = "$titlePrefix: $currentVal $unit"
            textSize = 17f
            setTextColor(Color.parseColor("#111111"))
        }
        val subTv = TextView(this).apply {
            text = subtitle
            textSize = 14f
            setTextColor(Color.parseColor("#0288D1"))
        }
        val seek = SeekBar(this).apply {
            max = maxVal - minVal
            progress = (currentVal - minVal).coerceIn(0, maxVal - minVal)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = minVal + progress
                    titleTv.text = "$titlePrefix: $v $unit"
                    onValueChange(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        col.addView(titleTv)
        col.addView(subTv)
        col.addView(seek)
        return col
    }

    private fun showNumberDialog(title: String, currentValue: Int, onResult: (Int) -> Unit) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(currentValue.toString())
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val v = input.text.toString().toIntOrNull()
                if (v != null) onResult(v) else Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
