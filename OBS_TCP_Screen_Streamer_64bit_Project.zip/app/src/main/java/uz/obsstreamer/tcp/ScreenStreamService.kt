package uz.obsstreamer.tcp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.Surface
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 64-bit Foreground Service for Hardware H.264 Screen Encoding + Audio Mixing + TCP MPEG-TS Streaming.
 *
 * Fixes all Android 10–15 & OBS edge cases:
 * 1. Calls startForeground() with FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION BEFORE obtaining MediaProjection
 *    (mandatory on Android 10–14+ to prevent SecurityException).
 * 2. Aligns video width & height to multiples of 16 (`(dim / 16) * 16`) so hardware H.264 encoders on
 *    Snapdragon, Exynos, Dimensity, and Tensor never crash with CodecException.
 * 3. Configures `KEY_REPEAT_PREVIOUS_FRAME_AFTER = 100_000L` (100ms) so static screens still emit keep-alive
 *    frames to OBS Studio, preventing TCP timeout and audio/video desync.
 * 4. Acquires partial WakeLock and Wi-Fi Low-Latency Lock (`WIFI_MODE_FULL_LOW_LATENCY`) so screen streaming
 *    never stutters when running in the background.
 */
class ScreenStreamService : Service() {

    companion object {
        const val ACTION_START = "uz.obsstreamer.tcp.ACTION_START"
        const val ACTION_STOP = "uz.obsstreamer.tcp.ACTION_STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "obs_tcp_stream_channel"
        private const val NOTIF_ID = 1001

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var connectedClientsCount: Int = 0
            private set

        val logs = CopyOnWriteArrayList<String>()
        var onStateListener: (() -> Unit)? = null

        fun addLog(msg: String) {
            val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            logs.add(0, "[$time] $msg")
            while (logs.size > 200) {
                logs.removeAt(logs.size - 1)
            }
            onStateListener?.invoke()
        }
    }

    private lateinit var settings: StreamSettings
    private val isStreaming = AtomicBoolean(false)

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var videoCodec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var videoThread: Thread? = null

    private var audioMixer: AudioMixerEncoder? = null
    private var tcpServer: TcpStreamServer? = null
    private val mpegTsMuxer = MpegTsMuxer()

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var currentOrientation: Int = Configuration.ORIENTATION_PORTRAIT

    override fun onCreate() {
        super.onCreate()
        settings = StreamSettings(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultData != null && !isStreaming.get()) {
                    startForegroundCompat()
                    startStreamingPipeline(resultCode, resultData)
                }
            }
            ACTION_STOP -> {
                stopStreamingPipeline()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val notification = buildNotification("Streaming ready on port ${settings.tcpPort}")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var fgType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && settings.audioSource != AudioSourceType.NONE) {
                fgType = fgType or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(NOTIF_ID, notification, fgType)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun startStreamingPipeline(resultCode: Int, resultData: Intent) {
        isStreaming.set(true)
        isServiceRunning = true
        currentOrientation = resources.configuration.orientation
        acquireLocks()

        try {
            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = mpManager.getMediaProjection(resultCode, resultData)
            projection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    addLog("MediaProjection stopped by system.")
                    stopStreamingPipeline()
                    stopSelf()
                }
            }, null)
            mediaProjection = projection

            // 1. Start TCP MPEG-TS Server
            val includeAudio = settings.audioSource != AudioSourceType.NONE
            tcpServer = TcpStreamServer(
                port = settings.tcpPort,
                onClientCountChanged = { count ->
                    connectedClientsCount = count
                    onStateListener?.invoke()
                },
                onRequestSyncFrame = { requestImmediateKeyframe() },
                onProvideInitialHeader = { mpegTsMuxer.buildPatPmtPackets(includeAudio) },
                onLog = { addLog(it) }
            ).also { it.start() }

            // 2. Start Hardware H.264 Video Encoder & VirtualDisplay
            startVideoEncoderAndDisplay()

            // 3. Start Audio Mixer (Internal + Microphone)
            audioMixer = AudioMixerEncoder(
                mediaProjection = projection,
                settings = settings,
                onEncodedAacFrame = { aacBytes, ptsUs ->
                    if (connectedClientsCount > 0) {
                        val tsPackets = mpegTsMuxer.muxAudioFrame(aacBytes, ptsUs)
                        tcpServer?.broadcastTsPackets(tsPackets, isKeyFrame = false)
                    }
                },
                onLog = { addLog(it) }
            ).also { it.start() }

            onStateListener?.invoke()
        } catch (e: Exception) {
            addLog("Fatal startup error: ${e.message}")
            stopStreamingPipeline()
            stopSelf()
        }
    }

    private fun startVideoEncoderAndDisplay() {
        val projection = mediaProjection ?: return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val rawW = metrics.widthPixels
        val rawH = metrics.heightPixels
        val isLandscape = settings.forceLandscape || (settings.autoRotate && rawW > rawH)

        val targetShortSide = settings.resolutionHeight
        val aspect = maxOf(rawW, rawH).toFloat() / minOf(rawW, rawH).toFloat()
        val targetLongSide = (targetShortSide * aspect).toInt()

        // Align dimensions to multiples of 16 (mandatory for all hardware H.264 macroblock encoders)
        val width = (((if (isLandscape) targetLongSide else targetShortSide) + 8) / 16) * 16
        val height = (((if (isLandscape) targetShortSide else targetLongSide) + 8) / 16) * 16

        val fps = settings.maxFps
        val bitrate = settings.videoBitrateKbps * 1000

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1-second GOP for instant OBS sync and recovery
            // Repeat previous frame every 100ms when screen is static so OBS TCP stream never stalls
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                setInteger(MediaFormat.KEY_PREPEND_HEADER_TO_SYNC_FRAMES, 1)
            }
            // Prefer Baseline / Constrained Baseline or Main profile with 0 B-frames for ultra-low latency
            setInteger(
                MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
            )
        }

        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = codec.createInputSurface()
        codec.start()

        videoCodec = codec
        inputSurface = surface

        virtualDisplay = projection.createVirtualDisplay(
            "OBSTcpScreenMirror",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            surface,
            null,
            null
        )

        addLog("H.264 Hardware Encoder started: ${width}x${height} @ ${fps}fps, ${settings.videoBitrateKbps} kbps")

        val includeAudio = settings.audioSource != AudioSourceType.NONE
        videoThread = Thread({
            drainVideoEncoder(codec, includeAudio)
        }, "ObsVideoEncoderThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun drainVideoEncoder(codec: MediaCodec, includeAudio: Boolean) {
        val bufferInfo = MediaCodec.BufferInfo()
        while (isStreaming.get() && videoCodec === codec) {
            try {
                val outIdx = codec.dequeueOutputBuffer(bufferInfo, 20_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = codec.outputFormat
                    val sps = newFormat.getByteBuffer("csd-0")?.let { buf ->
                        ByteArray(buf.remaining()).also { buf.get(it) }
                    }
                    val pps = newFormat.getByteBuffer("csd-1")?.let { buf ->
                        ByteArray(buf.remaining()).also { buf.get(it) }
                    }
                    mpegTsMuxer.setVideoCsd(sps, pps)
                    addLog("H.264 SPS/PPS headers locked.")
                } else if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && bufferInfo.size > 0) {
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        val nalBytes = ByteArray(bufferInfo.size)
                        outBuf.get(nalBytes)

                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            mpegTsMuxer.setVideoCsd(nalBytes, null)
                        } else if (connectedClientsCount > 0) {
                            val isKeyFrame = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                            val tsData = mpegTsMuxer.muxVideoFrame(
                                rawNalData = nalBytes,
                                presentationTimeUs = bufferInfo.presentationTimeUs,
                                isKeyFrame = isKeyFrame,
                                includeAudioInPmt = includeAudio
                            )
                            tcpServer?.broadcastTsPackets(tsData, isKeyFrame)
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                }
            } catch (e: Exception) {
                if (isStreaming.get() && videoCodec === codec) {
                    addLog("Video encoder warning: ${e.message}")
                }
                break
            }
        }
    }

    fun requestImmediateKeyframe() {
        try {
            val params = Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            }
            videoCodec?.setParameters(params)
        } catch (_: Exception) {}
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!isStreaming.get() || !settings.autoRotate || settings.forceLandscape) return
        if (newConfig.orientation != currentOrientation) {
            currentOrientation = newConfig.orientation
            addLog("Screen rotated; seamlessly reconfiguring H.264 encoder...")
            try {
                val oldCodec = videoCodec
                videoCodec = null
                virtualDisplay?.release()
                inputSurface?.release()
                oldCodec?.stop()
                oldCodec?.release()
                startVideoEncoderAndDisplay()
                requestImmediateKeyframe()
            } catch (e: Exception) {
                addLog("Rotation update error: ${e.message}")
            }
        }
    }

    private fun stopStreamingPipeline() {
        if (!isStreaming.getAndSet(false)) return
        isServiceRunning = false
        connectedClientsCount = 0

        tcpServer?.stop()
        tcpServer = null

        audioMixer?.stop()
        audioMixer = null

        try {
            videoThread?.join(400)
        } catch (_: Exception) {}
        videoThread = null

        try {
            virtualDisplay?.release()
        } catch (_: Exception) {}
        virtualDisplay = null

        try {
            inputSurface?.release()
        } catch (_: Exception) {}
        inputSurface = null

        try {
            videoCodec?.stop()
            videoCodec?.release()
        } catch (_: Exception) {}
        videoCodec = null

        try {
            mediaProjection?.stop()
        } catch (_: Exception) {}
        mediaProjection = null

        releaseLocks()
        addLog("Mirroring stopped.")
        onStateListener?.invoke()
    }

    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OBSTcpStreamer::CpuWakeLock").apply {
                acquire(6 * 60 * 60 * 1000L)
            }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wm.createWifiLock(lockMode, "OBSTcpStreamer::WifiLowLatencyLock").apply {
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {}
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OBS TCP Screen Streaming",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, ScreenStreamService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screen Stream Mirroring (64-bit)")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopStreamingPipeline()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
