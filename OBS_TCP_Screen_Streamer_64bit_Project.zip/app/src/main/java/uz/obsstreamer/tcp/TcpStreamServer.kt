package uz.obsstreamer.tcp

import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * High-stability TCP MPEG-TS Server for OBS Studio & VLC.
 *
 * Solves critical TCP streaming bugs:
 * 1. Non-blocking per-client bounded ring queue (250 packets): If Wi-Fi drops briefly, MediaCodec
 *    never blocks or crashes. If a client lags severely, old frames are dropped and an immediate
 *    IDR sync frame is requested.
 * 2. TCP_NODELAY enabled (`socket.tcpNoDelay = true`) for sub-80ms ultra-low latency in OBS.
 * 3. Instant PAT/PMT + IDR Keyframe request on new client accept so OBS displays video in <200ms.
 * 4. Automatic HTTP vs raw TCP detection: Works whether the user enters `tcp://IP:5000` or `http://IP:5000` in OBS/VLC!
 */
class TcpStreamServer(
    private val port: Int,
    private val onClientCountChanged: (Int) -> Unit,
    private val onRequestSyncFrame: () -> Unit,
    private val onProvideInitialHeader: () -> ByteArray?,
    private val onLog: (String) -> Unit
) {
    private val isRunning = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null
    private val clients = Collections.synchronizedList(mutableListOf<ClientWorker>())

    fun start() {
        if (isRunning.getAndSet(true)) return

        acceptThread = Thread({
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress("0.0.0.0", port))
                serverSocket = ss
                onLog("TCP Server started on port $port (Waiting for OBS / VLC connection...)")

                while (isRunning.get()) {
                    val socket = ss.accept()
                    socket.tcpNoDelay = true
                    socket.sendBufferSize = 256 * 1024
                    socket.soTimeout = 5000

                    val worker = ClientWorker(socket)
                    clients.add(worker)
                    worker.start()
                    onClientCountChanged(clients.size)
                    onLog("OBS/VLC connected from ${socket.inetAddress.hostAddress}:${socket.port} (Active: ${clients.size})")

                    // Immediately request an IDR Keyframe from MediaCodec so OBS starts decoding right away
                    onRequestSyncFrame()
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    onLog("TCP Server error: ${e.message}")
                }
            }
        }, "ObsTcpAcceptThread").apply { isDaemon = true; start() }
    }

    fun broadcastTsPackets(tsData: ByteArray, isKeyFrame: Boolean) {
        if (!isRunning.get() || clients.isEmpty()) return
        synchronized(clients) {
            val iterator = clients.iterator()
            while (iterator.hasNext()) {
                val client = iterator.next()
                if (!client.isAliveFlag.get()) {
                    iterator.remove()
                    onClientCountChanged(clients.size)
                } else {
                    client.enqueue(tsData, isKeyFrame)
                }
            }
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        synchronized(clients) {
            clients.forEach { it.closeClient() }
            clients.clear()
        }
        onClientCountChanged(0)
        onLog("TCP Server stopped.")
    }

    private inner class ClientWorker(private val socket: Socket) : Thread("ObsTcpClientWorker") {
        val isAliveFlag = AtomicBoolean(true)
        private val queue = ArrayBlockingQueue<ByteArray>(240)

        fun enqueue(data: ByteArray, isKeyFrame: Boolean) {
            if (!queue.offer(data)) {
                // Backpressure protection: clear stale P-frames and request fresh IDR sync frame
                queue.clear()
                if (isKeyFrame) {
                    queue.offer(data)
                } else {
                    onRequestSyncFrame()
                }
            }
        }

        override fun run() {
            try {
                val out: OutputStream = socket.getOutputStream()

                // Optional: Peek with a short timeout in case user entered http:// instead of tcp:// in VLC/OBS
                try {
                    socket.soTimeout = 120
                    val inp = socket.getInputStream()
                    val firstByte = inp.read()
                    if (firstByte == 'G'.code || firstByte == 'H'.code) {
                        val buf = ByteArray(512)
                        inp.read(buf)
                        val httpHeader = "HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\nConnection: close\r\nCache-Control: no-cache\r\n\r\n"
                        out.write(httpHeader.toByteArray(Charsets.US_ASCII))
                        out.flush()
                        onLog("Detected HTTP request from player; upgraded to MPEG-TS over HTTP.")
                    }
                } catch (_: Exception) {
                    // Normal raw TCP client (tcp://IP:5000) sends nothing; proceed immediately!
                } finally {
                    socket.soTimeout = 0
                }

                // Send initial PAT/PMT header immediately
                onProvideInitialHeader()?.let {
                    out.write(it)
                    out.flush()
                }

                while (isAliveFlag.get() && isRunning.get()) {
                    val packet = queue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                    out.write(packet)
                    if (queue.isEmpty()) {
                        out.flush()
                    }
                }
            } catch (e: Exception) {
                onLog("Client disconnected (${socket.inetAddress.hostAddress}): ${e.message ?: "EOF"}")
            } finally {
                closeClient()
                synchronized(clients) {
                    clients.remove(this)
                    onClientCountChanged(clients.size)
                }
            }
        }

        fun closeClient() {
            isAliveFlag.set(false)
            queue.clear()
            try {
                socket.close()
            } catch (_: Exception) {}
        }
    }

    companion object {
        /**
         * Finds all active IPv4 addresses (prioritizing USB Tethering `rndis`/`usb` and Wi-Fi `wlan`).
         */
        fun getLocalIpAddresses(preferUsbAdb: Boolean = false): List<Pair<String, String>> {
            if (preferUsbAdb) {
                return listOf("USB (ADB)" to "127.0.0.1")
            }
            val result = mutableListOf<Pair<String, String>>()
            try {
                val interfaces = NetworkInterface.getNetworkInterfaces() ?: return listOf("Local" to "127.0.0.1")
                for (ni in Collections.list(interfaces)) {
                    if (!ni.isUp || ni.isLoopback) continue
                    val name = ni.name.lowercase()
                    for (addr in Collections.list(ni.inetAddresses)) {
                        if (addr is Inet4Address && !addr.isLoopbackAddress) {
                            val ip = addr.hostAddress ?: continue
                            val label = when {
                                name.contains("rndis") || name.contains("usb") || name.contains("ncm") -> "USB Tethering"
                                name.contains("wlan") || name.contains("wifi") -> "Wi-Fi"
                                name.contains("ap") || name.contains("swlan") -> "Hotspot"
                                else -> name
                            }
                            result.add(label to ip)
                        }
                    }
                }
            } catch (_: Exception) {}
            if (result.isEmpty()) {
                result.add("Local" to "127.0.0.1")
            }
            // Sort so USB Tethering or Wi-Fi comes first
            return result.sortedBy {
                when (it.first) {
                    "USB Tethering" -> 0
                    "Wi-Fi" -> 1
                    "Hotspot" -> 2
                    else -> 3
                }
            }
        }
    }
}
