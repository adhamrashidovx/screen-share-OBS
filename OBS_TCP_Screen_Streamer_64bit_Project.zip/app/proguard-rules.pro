# Keep all streaming & muxing classes intact
-keep class uz.obsstreamer.tcp.** { *; }
