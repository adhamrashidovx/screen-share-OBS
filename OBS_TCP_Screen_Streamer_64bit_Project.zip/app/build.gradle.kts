plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "uz.obsstreamer.tcp"
    compileSdk = 34

    defaultConfig {
        applicationId = "uz.obsstreamer.tcp"
        minSdk = 29 // Android 10+ (Required for official Internal AudioPlaybackCapture & modern 64-bit MediaCodec)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0-64bit"

        // Strictly 64-bit architectures (arm64-v8a for all modern Android phones, x86_64 for emulators)
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Sign with debug key by default so release APK installs immediately without extra keystore setup
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
